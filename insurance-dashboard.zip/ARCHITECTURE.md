# Architecture & Engineering Notes

ABC Insurance — Claims Adjudication Workbench. This document covers the evaluation
focus areas: **architecture**, **performance strategy**, **data flow**, **RBAC
enforcement**, **large-document handling**, **reliability**, and **trade-offs**.

> Scope note: this repo is the **front-end reference** with a **mocked backend**. Where a
> real service would sit, a module in `src/mocks/` implements the same contract (latency,
> server-side ops, authorization). That keeps the *front-end* decisions — the thing being
> evaluated — honest and fully exercisable.

---

## 1. System overview

```
┌──────────────────────────────────────────────────────────────────────┐
│  Browser (React 18 + TS)                                               │
│                                                                        │
│  App shell ── Sidebar ── { DashboardPage | WorkspacePage }             │
│                                                                        │
│  DashboardPage                          WorkspacePage                  │
│   ├ StatStrip      (scoped aggregates)   ├ Document list               │
│   └ ClaimsGrid                           ├ DocumentViewer              │
│      • TanStack Virtual (rows)           │   • TanStack Virtual (pages)│
│      • useClaimsData (windowed fetch)    │   • useDocPages (windowed)  │
│      • optimistic mutations              ├ SidePanel (anno + comments) │
│                                          └ Ops (Split/Merge/Del/Export)│
│                                              └─ useDocWorker ──┐        │
│                                                                │        │
│  Auth context (RBAC mirror, UX only)                           │        │
│  Zustand store (navigation, session annotations/comments)      │        │
└────────────────────────────────────────────────────────────────┼──────┘
                          │ (HTTP contract, mocked)                │ postMessage
                          ▼                                        ▼
              src/mocks/mockApi.ts                        src/workers/docWorker.ts
              • applyScope  (RBAC, source of truth)       • chunked page ops
              • filter → sort → paginate                  • progress + cancel
              • mutations re-check authz                  • runs OFF main thread
              src/mocks/mockDocuments.ts
              • doc metadata; fetchPages(range) streaming
```

### Component boundaries & why

- **Pages own orchestration**, components own rendering. `ClaimsGrid` owns query state
  (sort/filter/search) and mutation flow; `ClaimRow` is a pure, memoized presentational
  unit. Same split in the workspace: `DocumentViewer` owns virtualization + fetch;
  `DocPageView` is pure.
- **Data-access is isolated in hooks** (`useClaimsData`, `useDocPages`, `useDocWorker`).
  Components don't know whether data comes from a mock, REST, or GraphQL — only the hook
  changes when the real backend lands.
- **The mock backend is a hard boundary.** Components never import the dataset; they only
  ever hold *one window* of it. This is enforced structurally: `mockApi.query()` returns a
  `Page<Claim>`, never the array.

### State management — deliberately layered, not one global store

| Concern | Where it lives | Why |
|---|---|---|
| Server data (rows, pages) | hook-local `useRef` caches + sparse maps | High-churn, large; must not trigger React reconciliation per row. Refs + a coalesced `force()` keep re-renders surgical. |
| Query state (sort/filter) | `useState` in `ClaimsGrid` | Local UI concern; drives the fetch key. |
| Cross-view state (active claim, nav) | Zustand | Shared between grid and workspace without prop-drilling. |
| Session collaboration (annotations, comments) | Zustand, keyed by docId | Must survive switching documents within a session. |
| Identity / permissions | React Context | Read-mostly, app-wide, rarely changes. |

This avoids the common failure mode of putting 20k rows in a global store and re-rendering
the world on every scroll tick. **The big data never enters React state at all** — it lives
in refs, and only the visible slice is rendered.

### Backend API assumptions

The mock encodes the contract the real service must honor:

- `GET /claims?page&pageSize&sort&filter` → `{ rows, total, tookMs }`, **authorization-scoped
  server-side**. Server-side sort/filter/paginate is mandatory at 20k+ (and required once
  the table grows past what any client should download).
- `GET /claims/{id}/documents` → lightweight metadata (page count, bytes) — **never** the file.
- `GET /documents/{id}/pages?start&count` → ranged page descriptors / tile URLs (think
  PDF.js range requests or IIIF). Enables partial/streamed loading.
- `POST /claims/{id}/assign|status`, `DELETE /claims/{id}` → re-check authz, return the
  updated entity.
- `POST /documents/{id}/{split|merge|delete-pages|export}` → returns a **job id**; progress
  via SSE/WebSocket/poll. (Mocked here by the worker's `postMessage` progress stream.)

---

## 2. Performance strategy

### 2.1 The 20,000-row grid

**Technique stack: server-side operations + row virtualization + windowed fetching +
memoized rows + optimistic mutation.**

1. **Server-side scope/filter/sort/paginate.** The client never sorts or filters 20k rows.
   It sends a query; the server returns one window. (`mockApi.query`.)
2. **Row virtualization** (`@tanstack/react-virtual`). The viewport renders ~15 rows +
   overscan regardless of total. DOM node count is *constant* whether the set is 20k or 2M.
3. **Windowed fetching with a sparse cache** (`useClaimsData`). The virtualizer reports the
   visible index range; the hook fetches the covering **page(s) of 100** and stores rows in
   a `Map<index, Claim>`. In-flight pages are de-duped; already-loaded pages are skipped.
   Unloaded rows render **skeletons**, so a fast scroll never blocks.
4. **Per-row memoization** (`React.memo` + stable `useCallback` handlers + a frozen `perms`
   object). A single row patch (e.g. an assignment) re-renders **one** row, not the list.
5. **Debounced search** (300 ms) so typing doesn't fire a request per keystroke.

> Net effect: scrolling the full 20k set keeps a flat, constant memory + DOM footprint and
> 60fps; the only network traffic is the page windows you actually scroll past.

### 2.2 The 150 MB – 1 GB document

The file is **never** downloaded or held in memory. The viewer holds metadata + a small
window of pages.

1. **Metadata-first.** `getClaimDocs` returns page counts / byte sizes only.
2. **Page virtualization** (`DocumentViewer`): only ~6 pages are mounted (overscan 3).
3. **Ranged streaming** (`useDocPages`, `fetchPages`): pages load in windows of 24 around
   the viewport — analogous to PDF.js range requests. Pending pages show a skeleton page.
4. **Zoom is a transform**, not a re-fetch; the virtualizer re-measures item size on scale
   change rather than reloading content.
5. **Heavy operations run in a Web Worker** (`docWorker.ts`): split/merge/delete/export
   process the document in **chunks (~60 ticks)**, posting incremental progress and
   honoring cancel. The main thread — and therefore scrolling/annotating — stays responsive
   throughout. In production each chunk is a ranged read → transform → write of a page
   batch; here it's a deterministic busy-slice so progress and cancel are *real*.

### 2.3 Rendering discipline

- Big data in **refs**, not state; updates coalesced through one `force()` reducer.
- Stable identities (`useMemo`/`useCallback`) across the memo boundary so rows/pages don't
  re-render on parent churn.
- Fixed row height → cheap virtualizer math; page height derived from scale.

---

## 3. RBAC — where authorization lives

**Rule: the backend is the source of truth. The frontend mirror is for UX only.**

- **Server-side (source of truth):** `mockApi.applyScope` filters every query to the
  records a role may read (region scoping), and every mutation (`assign`, `updateStatus`,
  `remove`) **re-checks the permission and region before committing** and throws `403`
  otherwise. A forged client request still fails here.
- **Frontend mirror (`src/auth/rbac.ts`):** a permission set per role used purely to
  **show / hide / disable** affordances — action buttons, annotation tools, op buttons —
  so users are never offered an action that would 403. The frontend never makes a security
  decision on this map.

This dual model is the standard answer: *defense at the server, ergonomics at the client.*
The Role switcher is a demo affordance; in production the role comes from the IdP/token.

---

## 4. Data flow

**Grid read:** query state change → `useClaimsData` keys on `{sort, filters, role}` →
resets cache, fetches page 0 + total → virtualizer renders window → scroll → `ensureRange`
fetches missing windows → rows fill in.

**Grid write (optimistic):** user submits (e.g. Assign) → `patchRow` updates the cached row
immediately → server call → on success patch with server truth + toast; on failure
`invalidate()` (full refetch to server truth) + error toast. Delete uses `invalidate`
because indices shift.

**Grid → workspace:** row click → `store.openWorkspace(claim)` → app swaps page → workspace
loads doc metadata, viewer streams pages.

**Document op:** click Split → `useDocWorker.start(kind, pageCount)` → worker streams
`DocOpProgress` → progress UI updates → Done/Cancel → toast → clear.

---

## 5. Reliability

- **Cancel/retry for long tasks.** The worker checks a cancel flag each chunk and reports a
  terminal `cancelled` state → "document unchanged." Failed mutations roll back to server
  truth.
- **Consistent state after ops.** Operations are modeled as jobs with a single terminal
  event; the UI only commits the new document state on a clean `done`. Partial failure ⇒ no
  partial commit (the chunked design makes resumable/transactional server ops natural).
- **Optimistic-with-rollback** keeps perceived latency low without risking divergence: the
  authoritative server response always wins.
- **Stale-response guarding.** The worker hook ignores progress from a job the user already
  dismissed; the fetch effect uses an `alive` flag so a slow first page can't overwrite a
  newer query.
- **Clear states everywhere:** skeletons (grid rows, doc pages, stat cards), per-query
  latency readout, progress bar with phase + page counts, toasts for success/error/cancel.

---

## 6. Trade-offs (and the calls made)

| Decision | Options | Call & rationale |
|---|---|---|
| 20k rows | pagination · infinite scroll · **virtualization + windowed fetch** | Chose virtualization + windowed server fetch. Pagination caps DOM but fragments scanning/scrolling and complicates "jump to row"; pure client infinite-scroll can't hold 20k+ safely. Virtualization gives constant DOM/memory *and* a continuous scroll, while windowing keeps network bounded. (Pagination remains the right call for deep-link/SEO list pages — not this workbench.) |
| Where ops run | main thread · **Web Worker** | Worker. GB-scale page ops on the main thread jank scroll and annotation. Worker keeps 60fps and makes cancel real. |
| Document loading | full download · **streamed/partial** | Streamed page windows. A 1 GB download is a non-starter for memory and TTFB; ranged page fetch gives instant first paint. |
| Updates | pessimistic · **optimistic + rollback** | Optimistic for snappy adjudication, with server-truth rollback so we never show a lie. |
| Server vs client processing | client · **server** for filter/sort/paginate | Server. Correctness + scale: the client must not need the full set to sort/filter, and authorization must be enforced before data leaves the server. |
| Caching | none · **sparse per-session window cache** | Per-session sparse cache (rows by index, pages by window) — cheap, bounded, invalidated on query/role change. A production build would layer React Query/SWR for ret[ry], dedupe, and background refresh. |
| Big data location | React state · **refs** | Refs + coalesced render. Putting large/high-churn data in state re-renders the tree on every scroll tick. |

### If this were production (next steps)

- Swap mock hooks for **React Query / RTK Query** (retry, dedupe, background refresh, cache
  GC) behind the same hook interface.
- Real document service with **range requests + CDN tiles**; ops as server jobs with
  **SSE/WebSocket** progress (the worker progress contract already matches).
- **Server-driven column/filter metadata** so the grid schema isn't hard-coded.
- **Virtual-scroll restoration**, URL-encoded query state (deep links), and a11y pass
  (ARIA grid roles, keyboard navigation, focus management in the viewer).
- Telemetry on the *tookMs* and frame budget already surfaced in the UI.
