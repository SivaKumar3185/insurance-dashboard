# ABC Insurance — Claims Adjudication Workbench

A reference front-end for the *Senior UI Engineering* use case: a scalable, high-performance
web app for adjudicating insurance claims over **large datasets (20,000+ records)** and
**very large documents (150 MB – 1 GB)**, with **role-based access control**.

Everything is **mocked** — there is no real backend. A simulated claims service
(`src/mocks/`) reproduces the exact contract a production API would expose (server-side
scope → filter → sort → paginate, with latency), and a Web Worker reproduces chunked,
cancellable document operations. This lets the UI architecture be evaluated end-to-end
without infrastructure.

The visual design follows the supplied Figma *CRM Dashboard – Customers List* (sidebar,
green stat cards, search, sortable table, status pills) re-themed to the claims domain.

---

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
```

```bash
npm run build      # typecheck + production bundle
npm run preview    # serve the production build
```

Requires Node 18+ (built on Node 22).

---

## What to try (demo script)

1. **Grid at scale** — the table holds **20,000 claims**. Scroll fast: rows beyond the
   viewport are never in the DOM (virtualized), and pages stream in with skeleton
   placeholders. Watch the *"server query Xms"* readout and *"rendering N of 20,000 rows."*
2. **Sort / filter / search** — click any column header (asc → desc → off), use the status
   filter chips, or the debounced search box. All of it runs "server-side" against the full
   dataset, not on the rendered page.
3. **Row actions** — Edit (status), Assign (adjuster), Delete. These are **optimistic**:
   the UI updates immediately and rolls back if the mock server rejects.
4. **RBAC (top-right Role switcher)** — flip between *Administrator, Senior Adjuster,
   Examiner, Auditor*. Notice:
   - the visible record **count changes** (region scoping is enforced server-side);
   - row action buttons **enable/disable**;
   - in the document workspace, annotation tools and split/merge/delete **gate** by role.
5. **Open a claim → document workspace** — click any row. A claim's documents (up to ~1 GB
   total, thousands of pages) open in a workspace. Scroll the viewer: pages **stream in
   windows**; only ~6 pages are ever mounted.
6. **Annotate** — pick Highlight / Note / Redact and click on a page. Add **page-level
   comments** in the right panel; resolve/reopen them.
7. **Large-document operations** — Split / Merge / Delete pages / Export run in a **Web
   Worker** with a live **progress bar** and a working **Cancel** (the UI never freezes).

---

## Role → permission matrix

| Capability            | Administrator | Senior Adjuster | Examiner | Auditor |
|-----------------------|:---:|:---:|:---:|:---:|
| View claims           | ✅ all regions | ✅ NA only | ✅ EU only | ✅ APAC only |
| Edit claim status     | ✅ | ✅ | ✅ | — |
| Assign adjuster       | ✅ | ✅ | — | — |
| Delete claim          | ✅ | — | — | — |
| View documents        | ✅ | ✅ | ✅ | ✅ |
| Annotate / comment    | ✅ | ✅ | ✅ | — |
| Split / merge / delete pages | ✅ | ✅ | — | — |
| Export                | ✅ | ✅ | — | — |

Defined in [`src/auth/rbac.ts`](src/auth/rbac.ts). Enforcement model is described in
[ARCHITECTURE.md](ARCHITECTURE.md#3-rbac--where-authorization-lives).

---

## Project map

```
src/
  mocks/         simulated backend: 20k-row generator, query API, large-doc model
  workers/       docWorker.ts — chunked, cancellable document operations (off main thread)
  auth/          RBAC roles + permissions + React context
  store/         Zustand: navigation + session annotations/comments
  components/
    grid/        virtualized 20k claims grid (windowed server fetch + TanStack Virtual)
    document/    large-document workspace (virtualized pages, annotations, ops)
    layout/      sidebar, stat strip, role switcher
    ui/          icons, primitives, toasts
  pages/         DashboardPage, WorkspacePage
```

See **[ARCHITECTURE.md](ARCHITECTURE.md)** for the full discussion of architecture,
performance strategy, data flow, and trade-offs.
