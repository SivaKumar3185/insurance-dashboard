import { AuthProvider } from "./auth/AuthContext";
import { Sidebar } from "./components/layout/Sidebar";
import { ToastHost } from "./components/ui/toast";
import { DashboardPage } from "./pages/DashboardPage";
import { WorkspacePage } from "./pages/WorkspacePage";
import { useStore } from "./store/useStore";

function Shell() {
  const view = useStore((s) => s.view);
  const collapsed = useStore((s) => s.sidebarCollapsed);
  return (
    <div
      className="shell"
      style={{ gridTemplateColumns: `${collapsed ? 84 : 250}px 1fr` }}
    >
      <Sidebar />
      {view === "dashboard" ? <DashboardPage /> : <WorkspacePage />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
      <ToastHost />
    </AuthProvider>
  );
}
