import {
  createContext,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { ROLES, can, type Permission, type Role, type RoleId } from "./rbac";

interface AuthValue {
  role: Role;
  roleId: RoleId;
  setRoleId: (id: RoleId) => void;
  can: (perm: Permission) => boolean;
  user: { name: string; title: string; avatar: string };
}

const AuthContext = createContext<AuthValue | null>(null);

const USERS: Record<RoleId, { name: string; title: string; avatar: string }> = {
  admin: { name: "Evano", title: "Claims Administrator", avatar: "EV" },
  adjuster: { name: "Marvin Kenter", title: "Senior Adjuster", avatar: "MK" },
  examiner: { name: "Kathryn Murphy", title: "Claims Examiner", avatar: "KM" },
  viewer: { name: "Floyd Miles", title: "Read-only Auditor", avatar: "FM" },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [roleId, setRoleId] = useState<RoleId>("admin");

  const value = useMemo<AuthValue>(() => {
    const role = ROLES[roleId];
    return {
      role,
      roleId,
      setRoleId,
      can: (perm: Permission) => can(role, perm),
      user: USERS[roleId],
    };
  }, [roleId]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
