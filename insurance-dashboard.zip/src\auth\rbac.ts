// ---------------------------------------------------------------------------
// Role-Based Access Control (RBAC)
//
// IMPORTANT (design intent):
//   The backend is the SOURCE OF TRUTH for authorization. Every list query is
//   scoped server-side to records the caller may see (see mockApi.applyScope),
//   and every mutating op is re-checked server-side before commit.
//
//   The permission map below is the FRONTEND MIRROR. It exists purely for UX:
//   show / hide / disable affordances so users aren't offered actions that
//   would 403. The frontend NEVER trusts this map for security decisions.
// ---------------------------------------------------------------------------

export type Permission =
  | "claims:read"
  | "claims:edit"
  | "claims:delete"
  | "claims:assign"
  | "claims:read-all-regions" // else scoped to own region
  | "doc:view"
  | "doc:annotate"
  | "doc:comment"
  | "doc:edit-pages" // split / merge / delete pages
  | "doc:export";

export type RoleId = "admin" | "adjuster" | "examiner" | "viewer";

export interface Role {
  id: RoleId;
  label: string;
  description: string;
  region: string; // the region this user is scoped to
  permissions: Set<Permission>;
}

const P = (...p: Permission[]) => new Set<Permission>(p);

export const ROLES: Record<RoleId, Role> = {
  admin: {
    id: "admin",
    label: "Claims Administrator",
    description: "Full access across all regions.",
    region: "ALL",
    permissions: P(
      "claims:read",
      "claims:edit",
      "claims:delete",
      "claims:assign",
      "claims:read-all-regions",
      "doc:view",
      "doc:annotate",
      "doc:comment",
      "doc:edit-pages",
      "doc:export",
    ),
  },
  adjuster: {
    id: "adjuster",
    label: "Senior Adjuster",
    description: "Edits & assigns claims in their region; full document tooling.",
    region: "North America",
    permissions: P(
      "claims:read",
      "claims:edit",
      "claims:assign",
      "doc:view",
      "doc:annotate",
      "doc:comment",
      "doc:edit-pages",
      "doc:export",
    ),
  },
  examiner: {
    id: "examiner",
    label: "Claims Examiner",
    description: "Reviews & annotates; cannot delete claims or edit document pages.",
    region: "Europe",
    permissions: P(
      "claims:read",
      "claims:edit",
      "doc:view",
      "doc:annotate",
      "doc:comment",
    ),
  },
  viewer: {
    id: "viewer",
    label: "Read-only Auditor",
    description: "Read-only across the region; no mutations of any kind.",
    region: "Asia Pacific",
    permissions: P("claims:read", "doc:view"),
  },
};

export function can(role: Role, perm: Permission): boolean {
  return role.permissions.has(perm);
}
