import { memo } from "react";
import type { Annotation, DocPage } from "../../types";

export type Tool = "select" | "highlight" | "note" | "redaction";

interface Props {
  page: DocPage | undefined;
  pageIndex: number;
  top: number;
  scale: number;
  baseW: number;
  baseH: number;
  annotations: Annotation[];
  tool: Tool;
  canAnnotate: boolean;
  onPlace: (pageIndex: number, x: number, y: number) => void;
  onRemoveAnno: (id: string) => void;
}

function DocPageViewBase({
  page,
  pageIndex,
  top,
  scale,
  baseW,
  baseH,
  annotations,
  tool,
  canAnnotate,
  onPlace,
  onRemoveAnno,
}: Props) {
  const w = baseW * scale;
  const h = baseH * scale;
  const armed = canAnnotate && tool !== "select";

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!armed) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    onPlace(pageIndex, x, y);
  };

  return (
    <div className="page-shell" style={{ top, width: w, transform: "translateX(-50%)" }}>
      <div
        className={`page ${armed ? "tool-armed" : ""}`}
        style={{ width: w, height: h }}
        onClick={handleClick}
      >
        <span className="page-num">Page {pageIndex + 1}</span>
        {page ? (
          <div className="page-text" style={{ fontSize: 13 * scale }}>
            {page.textPreview}
          </div>
        ) : (
          <div className="page-skel">
            <div className="skel" style={{ width: "60%", height: 16 }} />
            <div className="skel" style={{ width: "100%", height: 10, marginTop: 16 }} />
            <div className="skel" style={{ width: "92%", height: 10, marginTop: 8 }} />
            <div className="skel" style={{ width: "96%", height: 10, marginTop: 8 }} />
            <div className="skel" style={{ width: "70%", height: 10, marginTop: 8 }} />
          </div>
        )}

        {annotations.map((a) => (
          <div
            key={a.id}
            className={`anno ${a.type}`}
            style={{
              left: `${a.x * 100}%`,
              top: `${a.y * 100}%`,
              width: `${a.w * 100}%`,
              height: `${a.h * 100}%`,
            }}
            title={
              canAnnotate
                ? `${a.type} by ${a.author} — click to remove`
                : `${a.type} by ${a.author}`
            }
            onClick={(e) => {
              e.stopPropagation();
              if (canAnnotate) onRemoveAnno(a.id);
            }}
          >
            {a.type === "note" && a.text && <span className="anno-tip">{a.text}</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

export const DocPageView = memo(DocPageViewBase);
