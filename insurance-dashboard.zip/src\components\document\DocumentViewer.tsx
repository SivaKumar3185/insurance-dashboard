import { useEffect, useMemo, useRef } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useAuth } from "../../auth/AuthContext";
import { useStore } from "../../store/useStore";
import type { Annotation, DocMeta } from "../../types";
import { useDocPages } from "./useDocPages";
import { DocPageView, type Tool } from "./DocPageView";

const BASE_W = 680;
const BASE_H = 880;
const GAP = 24;

const ANNO_SIZES: Record<Exclude<Tool, "select">, { w: number; h: number }> = {
  highlight: { w: 0.34, h: 0.028 },
  note: { w: 0.16, h: 0.05 },
  redaction: { w: 0.34, h: 0.035 },
};

interface Props {
  doc: DocMeta;
  tool: Tool;
  scale: number;
  onCurrentPage: (page: number) => void;
}

export function DocumentViewer({ doc, tool, scale, onCurrentPage }: Props) {
  const { can, user } = useAuth();
  const canAnnotate = can("doc:annotate");
  const { ensureRange, getPage } = useDocPages(doc);

  const annosByDoc = useStore((s) => s.annotations[doc.id]);
  const addAnnotation = useStore((s) => s.addAnnotation);
  const removeAnnotation = useStore((s) => s.removeAnnotation);

  // group annotations by page once per change
  const annoByPage = useMemo(() => {
    const map = new Map<number, Annotation[]>();
    (annosByDoc ?? []).forEach((a) => {
      const arr = map.get(a.pageIndex) ?? [];
      arr.push(a);
      map.set(a.pageIndex, arr);
    });
    return map;
  }, [annosByDoc]);

  const parentRef = useRef<HTMLDivElement>(null);
  const itemSize = BASE_H * scale + GAP;
  const virtualizer = useVirtualizer({
    count: doc.pageCount,
    getScrollElement: () => parentRef.current,
    estimateSize: () => itemSize,
    overscan: 3,
  });

  // re-measure when zoom changes
  useEffect(() => {
    virtualizer.measure();
  }, [scale, virtualizer]);

  const items = virtualizer.getVirtualItems();
  const firstIdx = items[0]?.index ?? 0;
  const lastIdx = items[items.length - 1]?.index ?? 0;

  useEffect(() => {
    ensureRange(firstIdx, lastIdx);
    onCurrentPage(firstIdx);
  }, [firstIdx, lastIdx, ensureRange, onCurrentPage]);

  const handlePlace = (pageIndex: number, x: number, y: number) => {
    if (tool === "select" || !canAnnotate) return;
    const size = ANNO_SIZES[tool];
    addAnnotation({
      id: `anno-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      docId: doc.id,
      pageIndex,
      x: Math.max(0, Math.min(1 - size.w, x - size.w / 2)),
      y: Math.max(0, Math.min(1 - size.h, y - size.h / 2)),
      w: size.w,
      h: size.h,
      type: tool,
      color: tool === "redaction" ? "#15171c" : "#ffd600",
      author: user.name,
      text: tool === "note" ? "Review note" : undefined,
      createdAt: new Date().toISOString(),
    });
  };

  // The page is a fixed width; when the viewer column is narrower than the
  // page (e.g. sidebar expanded) the centered page would clip. Give the scroll
  // content a min-width = page width + gutters so it centers and scrolls
  // horizontally instead of being cut off on the left.
  const contentMinWidth = BASE_W * scale + 48;

  return (
    <div className="pages-scroll" ref={parentRef}>
      <div
        style={{
          height: virtualizer.getTotalSize(),
          position: "relative",
          minWidth: contentMinWidth,
        }}
      >
        {items.map((vi) => (
          <DocPageView
            key={vi.key}
            page={getPage(vi.index)}
            pageIndex={vi.index}
            top={vi.start}
            scale={scale}
            baseW={BASE_W}
            baseH={BASE_H}
            annotations={annoByPage.get(vi.index) ?? EMPTY}
            tool={tool}
            canAnnotate={canAnnotate}
            onPlace={handlePlace}
            onRemoveAnno={(id) => removeAnnotation(doc.id, id)}
          />
        ))}
      </div>
    </div>
  );
}

const EMPTY: Annotation[] = [];
