import { useAuth } from "../../auth/AuthContext";
import type { DocOpKind } from "../../types";
import { IconExport, IconMerge, IconSplit, IconTrash } from "../ui/icons";

interface Props {
  busy: boolean;
  onOp: (kind: DocOpKind) => void;
}

export function OperationsBar({ busy, onOp }: Props) {
  const { can } = useAuth();
  const canEditPages = can("doc:edit-pages");
  const canExport = can("doc:export");

  const ops: { kind: DocOpKind; label: string; icon: React.ReactNode; allowed: boolean }[] = [
    { kind: "split", label: "Split", icon: <IconSplit size={16} />, allowed: canEditPages },
    { kind: "merge", label: "Merge", icon: <IconMerge size={16} />, allowed: canEditPages },
    {
      kind: "delete-pages",
      label: "Delete pages",
      icon: <IconTrash size={16} />,
      allowed: canEditPages,
    },
    { kind: "export", label: "Export", icon: <IconExport size={16} />, allowed: canExport },
  ];

  return (
    <div className="ws-ops">
      {ops.map((op) => (
        <button
          key={op.kind}
          className="op-btn"
          disabled={!op.allowed || busy}
          title={op.allowed ? `${op.label} (runs in a worker)` : "No permission for this role"}
          onClick={() => onOp(op.kind)}
        >
          {op.icon}
          {op.label}
        </button>
      ))}
    </div>
  );
}
