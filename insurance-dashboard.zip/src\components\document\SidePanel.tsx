import { useMemo, useState } from "react";
import { useAuth } from "../../auth/AuthContext";
import { useStore } from "../../store/useStore";
import type { DocMeta } from "../../types";
import { Avatar } from "../ui/primitives";
import { toast } from "../ui/toast";

type Tab = "comments" | "annotations";

export function SidePanel({ doc, currentPage }: { doc: DocMeta; currentPage: number }) {
  const { can, user } = useAuth();
  const [tab, setTab] = useState<Tab>("comments");

  const comments = useStore((s) => s.comments[doc.id]);
  const annotations = useStore((s) => s.annotations[doc.id]);
  const addComment = useStore((s) => s.addComment);
  const toggleResolved = useStore((s) => s.toggleCommentResolved);
  const removeAnnotation = useStore((s) => s.removeAnnotation);

  const pageComments = useMemo(
    () => (comments ?? []).filter((c) => c.pageIndex === currentPage),
    [comments, currentPage],
  );
  const pageAnnos = useMemo(
    () => (annotations ?? []).filter((a) => a.pageIndex === currentPage),
    [annotations, currentPage],
  );

  const [draft, setDraft] = useState("");
  const canComment = can("doc:comment");
  const canAnnotate = can("doc:annotate");

  const submit = () => {
    const body = draft.trim();
    if (!body) return;
    addComment({
      id: `cmt-${Date.now()}`,
      docId: doc.id,
      pageIndex: currentPage,
      author: user.name,
      body,
      createdAt: new Date().toISOString(),
      resolved: false,
    });
    setDraft("");
    toast("success", `Comment added to page ${currentPage + 1}`);
  };

  return (
    <aside className="ws-side">
      <div className="side-tabs">
        <button
          className={tab === "comments" ? "active" : ""}
          onClick={() => setTab("comments")}
        >
          Comments ({(comments ?? []).length})
        </button>
        <button
          className={tab === "annotations" ? "active" : ""}
          onClick={() => setTab("annotations")}
        >
          Annotations ({(annotations ?? []).length})
        </button>
      </div>

      <div className="side-body">
        <div style={{ fontSize: 12, color: "var(--c-text-muted)", marginBottom: 14 }}>
          Showing page {currentPage + 1}
        </div>

        {tab === "comments" &&
          (pageComments.length === 0 ? (
            <div className="empty-note">No comments on this page yet.</div>
          ) : (
            pageComments.map((c) => (
              <div key={c.id} className={`comment ${c.resolved ? "resolved" : ""}`}>
                <div className="chead">
                  <Avatar initials={c.author.slice(0, 2).toUpperCase()} size={24} />
                  <b>{c.author}</b>
                  <span style={{ color: "var(--c-text-muted)", marginLeft: "auto" }}>
                    {new Date(c.createdAt).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                <div className="cbody">{c.body}</div>
                <div className="cfoot">
                  <button onClick={() => toggleResolved(doc.id, c.id)}>
                    {c.resolved ? "Reopen" : "Resolve"}
                  </button>
                </div>
              </div>
            ))
          ))}

        {tab === "annotations" &&
          (pageAnnos.length === 0 ? (
            <div className="empty-note">
              No annotations on this page.
              {canAnnotate && " Use the toolbar to highlight, note, or redact."}
            </div>
          ) : (
            pageAnnos.map((a) => (
              <div key={a.id} className="comment">
                <div className="chead">
                  <span
                    style={{
                      width: 12,
                      height: 12,
                      borderRadius: 3,
                      background:
                        a.type === "redaction"
                          ? "#15171c"
                          : a.type === "note"
                            ? "var(--c-primary)"
                            : "#ffd600",
                    }}
                  />
                  <b style={{ textTransform: "capitalize" }}>{a.type}</b>
                  <span style={{ color: "var(--c-text-muted)", marginLeft: "auto" }}>
                    {a.author}
                  </span>
                </div>
                {a.text && <div className="cbody">{a.text}</div>}
                {canAnnotate && (
                  <div className="cfoot">
                    <button onClick={() => removeAnnotation(doc.id, a.id)}>Remove</button>
                  </div>
                )}
              </div>
            ))
          ))}
      </div>

      {tab === "comments" && (
        <div className="comment-box">
          {canComment ? (
            <>
              <textarea
                placeholder={`Comment on page ${currentPage + 1}…`}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit();
                }}
              />
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 8 }}>
                <button className="btn btn-primary" onClick={submit} disabled={!draft.trim()}>
                  Comment
                </button>
              </div>
            </>
          ) : (
            <div className="empty-note" style={{ padding: "8px 0" }}>
              Your role can view but not comment.
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
