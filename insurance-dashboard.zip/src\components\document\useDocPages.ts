import { useCallback, useEffect, useReducer, useRef } from "react";
import { fetchPages } from "../../mocks/mockDocuments";
import type { DocMeta, DocPage } from "../../types";

// Pages stream in windows. A 1GB / ~4000-page document is never held in
// memory — only the ~30 pages around the viewport plus a small overscan.
const WINDOW = 24;

export function useDocPages(doc: DocMeta | null) {
  const [, force] = useReducer((x) => x + 1, 0);
  const cache = useRef(new Map<number, DocPage>());
  const loaded = useRef(new Set<number>()); // window indices
  const inflight = useRef(new Set<number>());

  useEffect(() => {
    cache.current = new Map();
    loaded.current = new Set();
    inflight.current = new Set();
    force();
  }, [doc?.id]);

  const ensureRange = useCallback(
    (start: number, end: number) => {
      if (!doc) return;
      const firstWin = Math.max(0, Math.floor(start / WINDOW));
      const lastWin = Math.floor(end / WINDOW);
      for (let win = firstWin; win <= lastWin; win++) {
        if (loaded.current.has(win) || inflight.current.has(win)) continue;
        inflight.current.add(win);
        fetchPages(doc, win * WINDOW, WINDOW).then((pages) => {
          pages.forEach((p) => cache.current.set(p.index, p));
          loaded.current.add(win);
          inflight.current.delete(win);
          force();
        });
      }
    },
    [doc],
  );

  const getPage = useCallback((index: number) => cache.current.get(index), []);

  return { ensureRange, getPage };
}
