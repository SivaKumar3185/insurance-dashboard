import { useCallback, useEffect, useRef, useState } from "react";
import type { DocOpKind, DocOpProgress } from "../../types";

// Owns one dedicated worker for the lifetime of the workspace. All heavy
// page operations run there so the viewer stays at 60fps.
export function useDocWorker() {
  const workerRef = useRef<Worker | null>(null);
  const [progress, setProgress] = useState<DocOpProgress | null>(null);
  const activeJob = useRef<string | null>(null);

  useEffect(() => {
    const w = new Worker(new URL("../../workers/docWorker.ts", import.meta.url), {
      type: "module",
    });
    w.onmessage = (e: MessageEvent<DocOpProgress>) => {
      // ignore stale messages from a job the user already dismissed
      if (e.data.jobId !== activeJob.current) return;
      setProgress(e.data);
    };
    workerRef.current = w;
    return () => w.terminate();
  }, []);

  const start = useCallback((kind: DocOpKind, totalPages: number) => {
    const jobId =
      (crypto as Crypto & { randomUUID?: () => string }).randomUUID?.() ??
      `job-${Date.now()}-${Math.random()}`;
    activeJob.current = jobId;
    setProgress({ jobId, kind, processed: 0, total: totalPages, phase: "Queued", done: false });
    workerRef.current?.postMessage({ type: "start", jobId, kind, totalPages });
    return jobId;
  }, []);

  const cancel = useCallback(() => {
    if (activeJob.current) {
      workerRef.current?.postMessage({ type: "cancel", jobId: activeJob.current });
    }
  }, []);

  const clear = useCallback(() => {
    activeJob.current = null;
    setProgress(null);
  }, []);

  return { progress, start, cancel, clear };
}
