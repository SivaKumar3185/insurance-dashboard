import { useState } from "react";
import type { Claim, ClaimStatus } from "../../types";

const ADJUSTERS = [
  "Marvin Kenter",
  "Kathryn Murphy",
  "Floyd Miles",
  "Jane Cooper",
  "Jerome Bell",
  "Esther Howard",
  "Cody Fisher",
];
const STATUSES: ClaimStatus[] = [
  "New",
  "In Review",
  "Approved",
  "Rejected",
  "Pending Docs",
];

function Backdrop({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

export function AssignModal({
  claim,
  busy,
  onClose,
  onSubmit,
}: {
  claim: Claim;
  busy: boolean;
  onClose: () => void;
  onSubmit: (adjuster: string) => void;
}) {
  const [adjuster, setAdjuster] = useState(claim.assignedTo ?? ADJUSTERS[0]);
  return (
    <Backdrop onClose={onClose}>
      <h3>Assign claim {claim.id}</h3>
      <p>
        Route <b>{claim.claimant}</b>'s {claim.policyType} claim to an adjuster.
      </p>
      <label className="field">
        <span>Adjuster</span>
        <select value={adjuster} onChange={(e) => setAdjuster(e.target.value)}>
          {ADJUSTERS.map((a) => (
            <option key={a}>{a}</option>
          ))}
        </select>
      </label>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose} disabled={busy}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={() => onSubmit(adjuster)}
          disabled={busy}
        >
          {busy ? "Assigning…" : "Assign"}
        </button>
      </div>
    </Backdrop>
  );
}

export function EditModal({
  claim,
  busy,
  onClose,
  onSubmit,
}: {
  claim: Claim;
  busy: boolean;
  onClose: () => void;
  onSubmit: (status: ClaimStatus) => void;
}) {
  const [status, setStatus] = useState<ClaimStatus>(claim.status);
  return (
    <Backdrop onClose={onClose}>
      <h3>Edit claim {claim.id}</h3>
      <p>Update the adjudication status for {claim.claimant}.</p>
      <label className="field">
        <span>Status</span>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as ClaimStatus)}
        >
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </label>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose} disabled={busy}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={() => onSubmit(status)}
          disabled={busy}
        >
          {busy ? "Saving…" : "Save"}
        </button>
      </div>
    </Backdrop>
  );
}

export function DeleteModal({
  claim,
  busy,
  onClose,
  onConfirm,
}: {
  claim: Claim;
  busy: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <Backdrop onClose={onClose}>
      <h3>Delete claim {claim.id}?</h3>
      <p>
        This permanently removes <b>{claim.claimant}</b>'s claim and its{" "}
        {claim.docCount} associated documents. This cannot be undone.
      </p>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose} disabled={busy}>
          Cancel
        </button>
        <button className="btn btn-danger" onClick={onConfirm} disabled={busy}>
          {busy ? "Deleting…" : "Delete"}
        </button>
      </div>
    </Backdrop>
  );
}
