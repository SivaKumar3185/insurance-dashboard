import { memo } from "react";
import type { Claim } from "../../types";
import { StatusBadge, Pill, formatUSD } from "../ui/primitives";
import { IconAssign, IconEdit, IconTrash } from "../ui/icons";

export interface RowPerms {
  edit: boolean;
  assign: boolean;
  remove: boolean;
}

interface Props {
  claim: Claim;
  top: number;
  height: number;
  perms: RowPerms;
  onOpen: (c: Claim) => void;
  onEdit: (c: Claim) => void;
  onAssign: (c: Claim) => void;
  onDelete: (c: Claim) => void;
}

function ClaimRowBase({ claim, top, height, perms, onOpen, onEdit, onAssign, onDelete }: Props) {
  const stop =
    (fn: () => void) => (e: React.MouseEvent) => {
      e.stopPropagation();
      fn();
    };

  return (
    <div
      className="grid-row"
      style={{ position: "absolute", left: 0, right: 0, top: 0, height, transform: `translateY(${top}px)` }}
      onClick={() => onOpen(claim)}
      title="Open document workspace"
    >
      <div className="cell">
        <div className="strong">{claim.claimant}</div>
        <div className="muted" style={{ fontSize: 12 }}>
          {claim.id} · {claim.region}
        </div>
      </div>
      <div className="cell">
        <Pill>{claim.policyType}</Pill>
      </div>
      <div className="cell muted">{claim.channel}</div>
      <div className="cell muted">{claim.email}</div>
      <div className="cell">{claim.country}</div>
      <div className="cell strong">{formatUSD(claim.amount)}</div>
      <div className="cell">
        <StatusBadge status={claim.status} />
      </div>
      <div className="row-actions" onClick={(e) => e.stopPropagation()}>
        <button
          className="icon-btn"
          disabled={!perms.edit}
          title={perms.edit ? "Edit status" : "No permission"}
          onClick={stop(() => onEdit(claim))}
        >
          <IconEdit size={17} />
        </button>
        <button
          className="icon-btn"
          disabled={!perms.assign}
          title={perms.assign ? "Assign adjuster" : "No permission"}
          onClick={stop(() => onAssign(claim))}
        >
          <IconAssign size={17} />
        </button>
        <button
          className="icon-btn danger"
          disabled={!perms.remove}
          title={perms.remove ? "Delete claim" : "No permission"}
          onClick={stop(() => onDelete(claim))}
        >
          <IconTrash size={17} />
        </button>
      </div>
    </div>
  );
}

// Memoized: a row only re-renders when its own claim/perms/position change,
// not when sibling rows or the parent grid re-render. Critical for 20k rows.
export const ClaimRow = memo(ClaimRowBase);

export function SkeletonRow({ top, height }: { top: number; height: number }) {
  return (
    <div
      className="grid-row"
      style={{ position: "absolute", left: 0, right: 0, top: 0, height, transform: `translateY(${top}px)` }}
    >
      <div className="cell">
        <div className="skel" style={{ width: "70%" }} />
        <div className="skel" style={{ width: "45%", marginTop: 6, height: 10 }} />
      </div>
      <div className="cell"><div className="skel" style={{ width: 60 }} /></div>
      <div className="cell"><div className="skel" style={{ width: 70 }} /></div>
      <div className="cell"><div className="skel" style={{ width: "80%" }} /></div>
      <div className="cell"><div className="skel" style={{ width: "60%" }} /></div>
      <div className="cell"><div className="skel" style={{ width: 60 }} /></div>
      <div className="cell"><div className="skel" style={{ width: 70, height: 22 }} /></div>
      <div className="row-actions"><div className="skel" style={{ width: 80, height: 20 }} /></div>
    </div>
  );
}
