import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useAuth } from "../../auth/AuthContext";
import { claimsApi } from "../../mocks/mockApi";
import { useStore } from "../../store/useStore";
import { toast } from "../ui/toast";
import { IconArrowDown, IconArrowUp, IconSearch } from "../ui/icons";
import type {
  Claim,
  ClaimFilters,
  ClaimStatus,
  SortDir,
  SortSpec,
} from "../../types";
import { useClaimsData } from "./useClaimsData";
import { ClaimRow, SkeletonRow, type RowPerms } from "./ClaimRow";
import { AssignModal, DeleteModal, EditModal } from "./ClaimModals";
import { Spinner } from "../ui/primitives";

const ROW_H = 64;

interface Column {
  key: keyof Claim | "actions";
  label: string;
  sortable: boolean;
}
const COLUMNS: Column[] = [
  { key: "claimant", label: "Claimant", sortable: true },
  { key: "policyType", label: "Policy", sortable: true },
  { key: "channel", label: "Channel", sortable: true },
  { key: "email", label: "Email", sortable: true },
  { key: "country", label: "Country", sortable: true },
  { key: "amount", label: "Amount", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "actions", label: "", sortable: false },
];

const STATUS_FILTERS: ClaimStatus[] = [
  "New",
  "In Review",
  "Approved",
  "Rejected",
  "Pending Docs",
];

type Modal =
  | { type: "assign" | "edit" | "delete"; claim: Claim }
  | null;

export function ClaimsGrid() {
  const { can, role } = useAuth();
  const openWorkspace = useStore((s) => s.openWorkspace);

  // ---- query state (drives the "server") ----
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [statusSel, setStatusSel] = useState<ClaimStatus[]>([]);
  const [sort, setSort] = useState<SortSpec | undefined>({
    field: "submittedAt",
    dir: "desc",
  });

  // debounce the search box so we don't refetch on every keystroke
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  const filters = useMemo<ClaimFilters>(
    () => ({ search, status: statusSel }),
    [search, statusSel],
  );

  const data = useClaimsData(sort, filters);

  // ---- virtualization ----
  const parentRef = useRef<HTMLDivElement>(null);
  const virtualizer = useVirtualizer({
    count: data.total,
    getScrollElement: () => parentRef.current,
    estimateSize: () => ROW_H,
    overscan: 10,
  });
  const items = virtualizer.getVirtualItems();
  const firstIdx = items[0]?.index ?? 0;
  const lastIdx = items[items.length - 1]?.index ?? 0;

  // fetch the windows that just scrolled into view
  useEffect(() => {
    if (data.total > 0) data.ensureRange(firstIdx, lastIdx);
  }, [firstIdx, lastIdx, data.total, data.ensureRange]);

  // ---- sorting ----
  const toggleSort = useCallback((field: keyof Claim) => {
    setSort((prev) => {
      if (!prev || prev.field !== field) return { field, dir: "asc" };
      if (prev.dir === "asc") return { field, dir: "desc" };
      return undefined; // third click clears
    });
    virtualizer.scrollToOffset(0);
  }, [virtualizer]);

  const sortDropdownValue = useMemo(() => {
    if (!sort) return "";
    return `${sort.field}:${sort.dir}`;
  }, [sort]);

  // ---- mutations (optimistic + RBAC-aware) ----
  const [modal, setModal] = useState<Modal>(null);
  const [busy, setBusy] = useState(false);

  const onAssignSubmit = async (adjuster: string) => {
    if (modal?.type !== "assign") return;
    const claim = modal.claim;
    setBusy(true);
    // optimistic
    data.patchRow({ ...claim, assignedTo: adjuster });
    try {
      const updated = await claimsApi.assign(claim.id, adjuster, role);
      data.patchRow(updated);
      toast("success", `Assigned ${claim.id} to ${adjuster}`);
      setModal(null);
    } catch (e) {
      data.invalidate(); // rollback to server truth
      toast("error", (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const onEditSubmit = async (status: ClaimStatus) => {
    if (modal?.type !== "edit") return;
    const claim = modal.claim;
    setBusy(true);
    data.patchRow({ ...claim, status });
    try {
      const updated = await claimsApi.updateStatus(claim.id, status, role);
      data.patchRow(updated);
      toast("success", `${claim.id} → ${status}`);
      setModal(null);
    } catch (e) {
      data.invalidate();
      toast("error", (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const onDeleteConfirm = async () => {
    if (modal?.type !== "delete") return;
    const claim = modal.claim;
    setBusy(true);
    try {
      await claimsApi.remove(claim.id, role);
      toast("success", `Deleted ${claim.id}`);
      setModal(null);
      data.invalidate(); // indices shift -> full refetch
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  // stable handlers for memoized rows
  const onOpen = useCallback((c: Claim) => openWorkspace(c), [openWorkspace]);
  const onEdit = useCallback((c: Claim) => setModal({ type: "edit", claim: c }), []);
  const onAssign = useCallback((c: Claim) => setModal({ type: "assign", claim: c }), []);
  const onDelete = useCallback((c: Claim) => setModal({ type: "delete", claim: c }), []);

  const perms = useMemo<RowPerms>(
    () => ({
      edit: can("claims:edit"),
      assign: can("claims:assign"),
      remove: can("claims:delete"),
    }),
    [can],
  );

  const toggleStatus = (s: ClaimStatus) =>
    setStatusSel((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s],
    );

  return (
    <section className="panel" style={{ flex: 1 }}>
      <div className="panel-head">
        <div>
          <h2>All Claims</h2>
          <div className="sub">
            {role.permissions.has("claims:read-all-regions")
              ? "All regions"
              : `Scoped to ${role.region}`}{" "}
            · {data.total.toLocaleString()} records
          </div>
        </div>
        <div className="panel-tools">
          <div className="searchbox" style={{ minWidth: 240, boxShadow: "none", border: "1px solid var(--c-border)" }}>
            <IconSearch size={18} />
            <input
              placeholder="Search claimant, ID, email…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
          </div>
          <div className="sort-select">
            <span>Sort by</span>
            <select
              value={sortDropdownValue}
              onChange={(e) => {
                const v = e.target.value;
                if (!v) return setSort(undefined);
                const [field, dir] = v.split(":");
                setSort({ field: field as keyof Claim, dir: dir as SortDir });
              }}
            >
              <option value="submittedAt:desc">Newest</option>
              <option value="submittedAt:asc">Oldest</option>
              <option value="amount:desc">Amount (high)</option>
              <option value="amount:asc">Amount (low)</option>
              <option value="claimant:asc">Claimant A–Z</option>
              {sortDropdownValue &&
                ![
                  "submittedAt:desc",
                  "submittedAt:asc",
                  "amount:desc",
                  "amount:asc",
                  "claimant:asc",
                ].includes(sortDropdownValue) && (
                  <option value={sortDropdownValue}>
                    {sort?.field} ({sort?.dir})
                  </option>
                )}
            </select>
          </div>
        </div>
      </div>

      {/* status filter chips */}
      <div className="panel-tools" style={{ marginBottom: 16 }}>
        <button
          className={`filter-chip ${statusSel.length === 0 ? "active" : ""}`}
          onClick={() => setStatusSel([])}
        >
          All
        </button>
        {STATUS_FILTERS.map((s) => (
          <button
            key={s}
            className={`filter-chip ${statusSel.includes(s) ? "active" : ""}`}
            onClick={() => toggleStatus(s)}
          >
            {s}
          </button>
        ))}
        <span style={{ marginLeft: "auto", fontSize: 12, color: "var(--c-text-muted)" }}>
          server query {data.tookMs}ms
        </span>
      </div>

      {/* grid */}
      <div className="grid">
        <div className="grid-head">
          {COLUMNS.map((col) => {
            const isSorted = sort?.field === col.key;
            return (
              <div
                key={col.key}
                className={`th ${col.sortable ? "" : "no-sort"} ${isSorted ? "sorted" : ""}`}
                onClick={() => col.sortable && toggleSort(col.key as keyof Claim)}
              >
                {col.label}
                {isSorted &&
                  (sort!.dir === "asc" ? (
                    <IconArrowUp size={13} />
                  ) : (
                    <IconArrowDown size={13} />
                  ))}
              </div>
            );
          })}
        </div>

        <div className="grid-viewport" ref={parentRef}>
          {data.initialLoading ? (
            <div style={{ position: "relative" }}>
              {Array.from({ length: 10 }).map((_, i) => (
                <SkeletonRow key={i} top={i * ROW_H} height={ROW_H} />
              ))}
            </div>
          ) : data.total === 0 ? (
            <div
              style={{
                display: "grid",
                placeItems: "center",
                height: "100%",
                color: "var(--c-text-muted)",
                gap: 8,
              }}
            >
              <IconSearch size={32} />
              <p>No claims match your filters.</p>
            </div>
          ) : (
            <div style={{ height: virtualizer.getTotalSize(), position: "relative" }}>
              {items.map((vi) => {
                const claim = data.getRow(vi.index);
                return claim ? (
                  <ClaimRow
                    key={claim.id}
                    claim={claim}
                    top={vi.start}
                    height={vi.size}
                    perms={perms}
                    onOpen={onOpen}
                    onEdit={onEdit}
                    onAssign={onAssign}
                    onDelete={onDelete}
                  />
                ) : (
                  <SkeletonRow key={vi.key} top={vi.start} height={vi.size} />
                );
              })}
            </div>
          )}
        </div>

        <div className="grid-foot">
          <div className="info">
            {data.initialLoading ? (
              <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
                <Spinner size={14} /> Loading…
              </span>
            ) : (
              <>
                Virtualized scroll · rendering {items.length} of{" "}
                {data.total.toLocaleString()} rows
              </>
            )}
          </div>
          <div className="info" style={{ fontSize: 12 }}>
            Rows {data.total ? firstIdx + 1 : 0}–{Math.min(lastIdx + 1, data.total)} in
            view
          </div>
        </div>
      </div>

      {modal?.type === "assign" && (
        <AssignModal
          claim={modal.claim}
          busy={busy}
          onClose={() => setModal(null)}
          onSubmit={onAssignSubmit}
        />
      )}
      {modal?.type === "edit" && (
        <EditModal
          claim={modal.claim}
          busy={busy}
          onClose={() => setModal(null)}
          onSubmit={onEditSubmit}
        />
      )}
      {modal?.type === "delete" && (
        <DeleteModal
          claim={modal.claim}
          busy={busy}
          onClose={() => setModal(null)}
          onConfirm={onDeleteConfirm}
        />
      )}
    </section>
  );
}
