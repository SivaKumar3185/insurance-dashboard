import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { useAuth } from "../../auth/AuthContext";
import { claimsApi } from "../../mocks/mockApi";
import type { Claim, ClaimFilters, SortSpec } from "../../types";

// One server page == one fetch window. The virtualizer renders ~20 rows but we
// fetch in pages of 100 so a fast scroll doesn't fire a request per row.
const PAGE = 100;

export interface ClaimsData {
  total: number;
  tookMs: number;
  initialLoading: boolean;
  /** Row at absolute index, or undefined if its page hasn't loaded yet. */
  getRow: (index: number) => Claim | undefined;
  /** Ask the source to make sure every row in [start,end] is loaded. */
  ensureRange: (start: number, end: number) => void;
  /** Optimistic single-row patch (assign / status). */
  patchRow: (claim: Claim) => void;
  /** Force a full reset + refetch (after delete, or rollback). */
  invalidate: () => void;
}

export function useClaimsData(sort: SortSpec | undefined, filters: ClaimFilters): ClaimsData {
  const { role } = useAuth();
  const [, force] = useReducer((x) => x + 1, 0);
  const [total, setTotal] = useState(0);
  const [tookMs, setTookMs] = useState(0);
  const [initialLoading, setInitialLoading] = useState(true);
  const [resetKey, setResetKey] = useState(0);

  const cache = useRef(new Map<number, Claim>());
  const loadedPages = useRef(new Set<number>());
  const inflight = useRef(new Set<number>());

  // Serialize the query so the reset effect only fires on real changes.
  const queryKey = JSON.stringify({ sort, filters, role: role.id, resetKey });

  useEffect(() => {
    let alive = true;
    cache.current = new Map();
    loadedPages.current = new Set();
    inflight.current = new Set();
    setInitialLoading(true);
    inflight.current.add(0);

    claimsApi
      .query({ page: 0, pageSize: PAGE, sort, filters }, role)
      .then((res) => {
        if (!alive) return;
        res.rows.forEach((r, i) => cache.current.set(i, r));
        loadedPages.current.add(0);
        inflight.current.delete(0);
        setTotal(res.total);
        setTookMs(res.tookMs);
        setInitialLoading(false);
        force();
      });

    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey]);

  const ensureRange = useCallback(
    (start: number, end: number) => {
      const firstPage = Math.max(0, Math.floor(start / PAGE));
      const lastPage = Math.floor(end / PAGE);
      for (let p = firstPage; p <= lastPage; p++) {
        if (loadedPages.current.has(p) || inflight.current.has(p)) continue;
        inflight.current.add(p);
        claimsApi
          .query({ page: p, pageSize: PAGE, sort, filters }, role)
          .then((res) => {
            res.rows.forEach((r, i) => cache.current.set(p * PAGE + i, r));
            loadedPages.current.add(p);
            inflight.current.delete(p);
            setTookMs(res.tookMs);
            force();
          });
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [queryKey],
  );

  const getRow = useCallback((index: number) => cache.current.get(index), []);

  const patchRow = useCallback((claim: Claim) => {
    for (const [idx, row] of cache.current) {
      if (row.id === claim.id) {
        cache.current.set(idx, claim);
        break;
      }
    }
    force();
  }, []);

  const invalidate = useCallback(() => setResetKey((k) => k + 1), []);

  return { total, tookMs, initialLoading, getRow, ensureRange, patchRow, invalidate };
}
