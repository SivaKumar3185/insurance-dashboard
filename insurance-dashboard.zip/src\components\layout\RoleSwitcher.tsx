import { useAuth } from "../../auth/AuthContext";
import { ROLES, type RoleId } from "../../auth/rbac";
import { IconLock } from "../ui/icons";

// Demo-only affordance: lets evaluators flip identity to see RBAC live.
// In production the role comes from the auth token / IdP claims.
export function RoleSwitcher() {
  const { roleId, setRoleId, role } = useAuth();
  return (
    <div className="role-switch" title={role.description}>
      <IconLock size={16} color="var(--c-primary)" />
      <label>Role</label>
      <select value={roleId} onChange={(e) => setRoleId(e.target.value as RoleId)}>
        {Object.values(ROLES).map((r) => (
          <option key={r.id} value={r.id}>
            {r.label}
          </option>
        ))}
      </select>
    </div>
  );
}
