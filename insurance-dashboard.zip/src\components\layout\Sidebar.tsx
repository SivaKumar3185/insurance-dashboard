import { useAuth } from "../../auth/AuthContext";
import { useStore } from "../../store/useStore";
import { Avatar } from "../ui/primitives";
import {
  IconChart,
  IconChevronLeft,
  IconChevronRight,
  IconClaims,
  IconGrid,
  IconHelp,
  IconMegaphone,
  IconMenu,
  IconUsers,
} from "../ui/icons";

const NAV = [
  { key: "dashboard", label: "Dashboard", icon: IconGrid, enabled: true },
  { key: "claims", label: "Claims", icon: IconClaims, enabled: true, active: true },
  { key: "customers", label: "Customers", icon: IconUsers, enabled: true },
  { key: "reports", label: "Reports", icon: IconChart, enabled: true },
  { key: "promote", label: "Promote", icon: IconMegaphone, enabled: true },
  { key: "help", label: "Help", icon: IconHelp, enabled: true },
];

export function Sidebar() {
  const { user, role } = useAuth();
  const collapsed = useStore((s) => s.sidebarCollapsed);
  const toggleSidebar = useStore((s) => s.toggleSidebar);

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="brand">
        <span className="brand-logo">
          <IconClaims size={18} />
        </span>
        {!collapsed && (
          <span className="brand-text">
            ABC <small>Claims</small>
          </span>
        )}
        <button
          className="collapse-btn"
          onClick={toggleSidebar}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <IconMenu size={18} /> : <IconChevronLeft size={18} />}
        </button>
      </div>

      <nav className="nav">
        {NAV.map((n) => {
          const Icon = n.icon;
          return (
            <button
              key={n.key}
              className={`nav-item ${n.active ? "active" : ""} ${
                n.enabled ? "" : "disabled"
              }`}
              title={collapsed ? n.label : n.enabled ? undefined : "Not available in this demo"}
            >
              <Icon size={20} />
              {!collapsed && (
                <>
                  {n.label}
                  <IconChevronRight size={16} className="chev" />
                </>
              )}
            </button>
          );
        })}
      </nav>

      <div className="user-card" title={collapsed ? `${user.name} · ${role.label}` : undefined}>
        <Avatar initials={user.avatar} />
        {!collapsed && (
          <div className="meta">
            <b>{user.name}</b>
            <br />
            <span>{role.label}</span>
          </div>
        )}
      </div>
    </aside>
  );
}
