import { useEffect, useState } from "react";
import { useAuth } from "../../auth/AuthContext";
import { claimsApi } from "../../mocks/mockApi";
import { formatUSD } from "../ui/primitives";
import {
  IconArrowDown,
  IconArrowUp,
  IconClaims,
  IconMonitor,
  IconUsers,
} from "../ui/icons";

interface Stats {
  totalClaims: number;
  openClaims: number;
  avgAmount: number;
  activeAdjusters: number;
}

export function StatStrip() {
  const { role } = useAuth();
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    let alive = true;
    setStats(null);
    claimsApi.stats(role).then((s) => alive && setStats(s));
    return () => {
      alive = false;
    };
  }, [role]);

  const cards = [
    {
      label: "Total Claims",
      value: stats ? stats.totalClaims.toLocaleString() : null,
      icon: <IconUsers size={26} />,
      trend: { dir: "up" as const, text: "16% this month" },
    },
    {
      label: "Open Claims",
      value: stats ? stats.openClaims.toLocaleString() : null,
      icon: <IconClaims size={26} />,
      trend: { dir: "down" as const, text: "1% this month" },
    },
    {
      label: "Avg. Claim Value",
      value: stats ? formatUSD(stats.avgAmount) : null,
      icon: <IconMonitor size={26} />,
      trend: { dir: "up" as const, text: "4% this month" },
    },
    {
      label: "Active Adjusters",
      value: stats ? stats.activeAdjusters.toLocaleString() : null,
      icon: <IconUsers size={26} />,
      trend: { dir: "up" as const, text: "live now" },
    },
  ];

  return (
    <div className="stat-strip">
      {cards.map((c) => (
        <div className="stat" key={c.label}>
          <span className="ic">{c.icon}</span>
          <div>
            <div className="label">{c.label}</div>
            <div className="value">
              {c.value ?? <span className="skel" style={{ width: 80, display: "inline-block" }}>&nbsp;</span>}
            </div>
            <div className={`trend ${c.trend.dir}`}>
              {c.trend.dir === "up" ? (
                <IconArrowUp size={12} />
              ) : (
                <IconArrowDown size={12} />
              )}{" "}
              {c.trend.text}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
