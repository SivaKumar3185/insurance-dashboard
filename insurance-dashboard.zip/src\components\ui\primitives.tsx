import type { ClaimStatus } from "../../types";

export function Spinner({ size = 18 }: { size?: number }) {
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        border: `2.5px solid var(--c-primary-soft)`,
        borderTopColor: "var(--c-primary)",
        borderRadius: "50%",
        animation: "spin 0.7s linear infinite",
      }}
    />
  );
}

const STATUS_STYLE: Record<ClaimStatus, { bg: string; fg: string }> = {
  Approved: { bg: "var(--c-green-bg)", fg: "var(--c-green)" },
  New: { bg: "var(--c-blue-bg)", fg: "var(--c-blue)" },
  "In Review": { bg: "var(--c-amber-bg)", fg: "var(--c-amber)" },
  "Pending Docs": { bg: "var(--c-amber-bg)", fg: "var(--c-amber)" },
  Rejected: { bg: "var(--c-red-bg)", fg: "var(--c-red)" },
};

export function StatusBadge({ status }: { status: ClaimStatus }) {
  const s = STATUS_STYLE[status];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        background: s.bg,
        color: s.fg,
        fontSize: 12,
        fontWeight: 500,
        padding: "5px 14px",
        borderRadius: 6,
        whiteSpace: "nowrap",
      }}
    >
      {status}
    </span>
  );
}

export function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        background: "var(--c-primary-soft)",
        color: "var(--c-primary)",
        fontSize: 11,
        fontWeight: 500,
        padding: "3px 9px",
        borderRadius: 6,
      }}
    >
      {children}
    </span>
  );
}

export function Avatar({ initials, size = 36 }: { initials: string; size?: number }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: size,
        height: size,
        borderRadius: "50%",
        background: "linear-gradient(135deg, #5932EA, #9d7bff)",
        color: "#fff",
        fontSize: size * 0.36,
        fontWeight: 600,
        flexShrink: 0,
      }}
    >
      {initials}
    </span>
  );
}

export function ProgressBar({ value }: { value: number }) {
  return (
    <div
      style={{
        height: 8,
        background: "var(--c-primary-soft)",
        borderRadius: 99,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          height: "100%",
          width: `${Math.min(100, Math.max(0, value))}%`,
          background: "linear-gradient(90deg, #5932EA, #9d7bff)",
          borderRadius: 99,
          transition: "width 0.15s ease",
        }}
      />
    </div>
  );
}

export function formatBytes(bytes: number): string {
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(0)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${bytes} B`;
}

export function formatUSD(n: number): string {
  return n.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  });
}
