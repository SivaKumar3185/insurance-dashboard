import type { Channel, Claim, ClaimStatus, PolicyType } from "../types";

// Deterministic, seeded generation so the dataset is stable across reloads.
// mulberry32 — tiny fast PRNG.
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FIRST = [
  "Jane", "Floyd", "Ronald", "Marvin", "Jerome", "Kathryn", "Jacob", "Kristin",
  "Cody", "Esther", "Cameron", "Devon", "Albert", "Bessie", "Eleanor", "Darrell",
  "Annette", "Wade", "Dianne", "Theresa", "Courtney", "Brooklyn", "Marcus", "Lena",
];
const LAST = [
  "Cooper", "Miles", "Richards", "McKinney", "Bell", "Murphy", "Jones", "Watson",
  "Fisher", "Howard", "Williamson", "Lane", "Flores", "Cooper", "Pena", "Steward",
  "Black", "Warren", "Russell", "Webb", "Henry", "Simmons", "Hughes", "Patel",
];
const COMPANIES = [
  "Microsoft", "Yahoo", "Adobe", "Tesla", "Google", "Facebook", "Amazon",
  "Oracle", "Netflix", "Stripe", "Uber", "Airbnb", "Shopify", "Spotify",
];
const STATUSES: ClaimStatus[] = [
  "New", "In Review", "Approved", "Rejected", "Pending Docs",
];
const CHANNELS: Channel[] = ["Email", "SFTP", "Web Portal", "Mobile App", "Fax"];
const POLICIES: PolicyType[] = [
  "Auto", "Home", "Health", "Life", "Travel", "Commercial",
];
const PRIORITIES: Claim["priority"][] = ["Low", "Medium", "High"];

// region -> countries (region drives RBAC scoping)
const REGIONS: Record<string, string[]> = {
  "North America": ["United States", "Canada", "Mexico"],
  Europe: ["United Kingdom", "Germany", "France", "Spain", "Italy"],
  "Asia Pacific": ["India", "Japan", "Australia", "Singapore", "South Korea"],
  "Middle East & Africa": ["UAE", "Israel", "South Africa", "Kenya"],
  "Latin America": ["Brazil", "Argentina", "Chile", "Colombia"],
};
const REGION_NAMES = Object.keys(REGIONS);

const ADJUSTERS = [
  "Marvin Kenter", "Kathryn Murphy", "Floyd Miles", "Jane Cooper",
  "Jerome Bell", "Esther Howard", "Cody Fisher", null, null,
];

const pick = <T,>(rng: () => number, arr: T[]): T =>
  arr[Math.floor(rng() * arr.length)];

export const TOTAL_CLAIMS = 20_000;

let _cache: Claim[] | null = null;

/** Generate (once) and cache the full mock dataset. */
export function getAllClaims(): Claim[] {
  if (_cache) return _cache;
  const rng = mulberry32(424242);
  const rows: Claim[] = [];
  const now = Date.now();

  for (let i = 0; i < TOTAL_CLAIMS; i++) {
    const first = pick(rng, FIRST);
    const last = pick(rng, LAST);
    const company = pick(rng, COMPANIES);
    const region = pick(rng, REGION_NAMES);
    const country = pick(rng, REGIONS[region]);
    const status = pick(rng, STATUSES);
    const policyType = pick(rng, POLICIES);
    const docCount = 1 + Math.floor(rng() * 12);
    // total document payload 150MB .. ~1GB to match the spec
    const docSizeMB = Math.round(150 + rng() * 850);
    const daysAgo = Math.floor(rng() * 540);

    rows.push({
      id: `CLM-${(100000 + i).toString()}`,
      claimant: `${first} ${last}`,
      company,
      policyType,
      channel: pick(rng, CHANNELS),
      phone: `(${200 + Math.floor(rng() * 700)}) 555-${(1000 + Math.floor(rng() * 8999))
        .toString()
        .slice(0, 4)}`,
      email: `${first.toLowerCase()}@${company.toLowerCase()}.com`,
      country,
      amount: Math.round((500 + rng() * 249500) / 5) * 5,
      status,
      assignedTo: pick(rng, ADJUSTERS),
      region,
      submittedAt: new Date(now - daysAgo * 86_400_000).toISOString(),
      docCount,
      docSizeMB,
      priority: pick(rng, PRIORITIES),
    });
  }

  _cache = rows;
  return rows;
}
