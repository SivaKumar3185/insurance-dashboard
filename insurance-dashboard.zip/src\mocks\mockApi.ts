import type { Role } from "../auth/rbac";
import type {
  Claim,
  ClaimFilters,
  ClaimQuery,
  ClaimStatus,
  Page,
} from "../types";
import { getAllClaims } from "./generateClaims";

// ---------------------------------------------------------------------------
// Simulated backend.
//
// This module stands in for a real claims service. Every operation that a
// production frontend would do over HTTP (scope -> filter -> sort -> paginate)
// happens HERE, "server side", off the React render path. The grid only ever
// receives one page (e.g. 50 rows) regardless of the 20k total — exactly the
// contract a real server-side-pagination API would expose.
//
// Authorization is enforced here (applyScope), not in the UI, mirroring the
// "backend is the source of truth" rule.
// ---------------------------------------------------------------------------

function latency(min = 120, max = 320): Promise<void> {
  const ms = min + Math.random() * (max - min);
  return new Promise((r) => setTimeout(r, ms));
}

/** RBAC: restrict the visible record set to what this role may read. */
function applyScope(rows: Claim[], role: Role): Claim[] {
  if (role.permissions.has("claims:read-all-regions")) return rows;
  return rows.filter((r) => r.region === role.region);
}

function applyFilters(rows: Claim[], filters: ClaimFilters | undefined): Claim[] {
  if (!filters) return rows;
  let out = rows;
  const { search, status, channel, policyType, assignedToMe } = filters;

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    out = out.filter(
      (r) =>
        r.claimant.toLowerCase().includes(q) ||
        r.id.toLowerCase().includes(q) ||
        r.email.toLowerCase().includes(q) ||
        r.company.toLowerCase().includes(q) ||
        r.country.toLowerCase().includes(q),
    );
  }
  if (status && status.length) {
    const set = new Set<ClaimStatus>(status);
    out = out.filter((r) => set.has(r.status));
  }
  if (channel && channel.length) {
    const set = new Set(channel);
    out = out.filter((r) => set.has(r.channel));
  }
  if (policyType && policyType.length) {
    const set = new Set(policyType);
    out = out.filter((r) => set.has(r.policyType));
  }
  if (assignedToMe) {
    // "me" is naively the role's display region owner in this mock; in a real
    // system this would be the authenticated user id.
    out = out.filter((r) => r.assignedTo != null);
  }
  return out;
}

function applySort(rows: Claim[], query: ClaimQuery): Claim[] {
  const sort = query.sort;
  if (!sort) return rows;
  const { field, dir } = sort;
  const mult = dir === "asc" ? 1 : -1;
  // copy before sort so we never mutate the cached master array
  return [...rows].sort((a, b) => {
    const av = a[field];
    const bv = b[field];
    if (av == null && bv == null) return 0;
    if (av == null) return 1;
    if (bv == null) return -1;
    if (typeof av === "number" && typeof bv === "number") {
      return (av - bv) * mult;
    }
    return String(av).localeCompare(String(bv)) * mult;
  });
}

export const claimsApi = {
  /** Server-side paginated query. Returns exactly one page. */
  async query(query: ClaimQuery, role: Role): Promise<Page<Claim>> {
    const t0 = performance.now();
    await latency();
    const scoped = applyScope(getAllClaims(), role);
    const filtered = applyFilters(scoped, query.filters);
    const sorted = applySort(filtered, query);
    const start = query.page * query.pageSize;
    const rows = sorted.slice(start, start + query.pageSize);
    return {
      rows,
      total: filtered.length,
      page: query.page,
      pageSize: query.pageSize,
      tookMs: Math.round(performance.now() - t0),
    };
  },

  /** Aggregate stat-card numbers, computed within the caller's scope. */
  async stats(role: Role): Promise<{
    totalClaims: number;
    openClaims: number;
    avgAmount: number;
    activeAdjusters: number;
  }> {
    await latency(80, 160);
    const scoped = applyScope(getAllClaims(), role);
    const open = scoped.filter(
      (r) => r.status === "New" || r.status === "In Review" || r.status === "Pending Docs",
    ).length;
    const sum = scoped.reduce((acc, r) => acc + r.amount, 0);
    const adjusters = new Set(scoped.map((r) => r.assignedTo).filter(Boolean));
    return {
      totalClaims: scoped.length,
      openClaims: open,
      avgAmount: scoped.length ? Math.round(sum / scoped.length) : 0,
      activeAdjusters: adjusters.size,
    };
  },

  /** Mutations re-check authorization server-side before committing. */
  async assign(claimId: string, adjuster: string, role: Role): Promise<Claim> {
    await latency(150, 300);
    if (!role.permissions.has("claims:assign")) {
      throw new Error("403: not authorized to assign claims");
    }
    const row = getAllClaims().find((r) => r.id === claimId);
    if (!row) throw new Error("404: claim not found");
    if (!role.permissions.has("claims:read-all-regions") && row.region !== role.region) {
      throw new Error("403: claim outside your region");
    }
    row.assignedTo = adjuster; // mutate the in-memory store
    return { ...row };
  },

  async updateStatus(claimId: string, status: ClaimStatus, role: Role): Promise<Claim> {
    await latency(150, 300);
    if (!role.permissions.has("claims:edit")) {
      throw new Error("403: not authorized to edit claims");
    }
    const row = getAllClaims().find((r) => r.id === claimId);
    if (!row) throw new Error("404: claim not found");
    row.status = status;
    return { ...row };
  },

  async remove(claimId: string, role: Role): Promise<void> {
    await latency(150, 300);
    if (!role.permissions.has("claims:delete")) {
      throw new Error("403: not authorized to delete claims");
    }
    const all = getAllClaims();
    const idx = all.findIndex((r) => r.id === claimId);
    if (idx >= 0) all.splice(idx, 1);
  },
};
