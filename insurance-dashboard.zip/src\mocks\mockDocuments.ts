import type { Claim, DocMeta, DocPage } from "../types";

// ---------------------------------------------------------------------------
// Large-document mock.
//
// A claim's "documents" can total 150MB–1GB. We NEVER materialize that in
// memory. Instead each document exposes:
//   - lightweight metadata (page count, byte size)
//   - a `fetchPages(range)` that streams a window of page descriptors on demand
//
// This mirrors a real tiled/paged document service (think IIIF / PDF.js range
// requests): the client holds metadata + a small window of pages, not the file.
// ---------------------------------------------------------------------------

const BYTES_PER_PAGE = 256 * 1024; // ~256KB/page average

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const DOC_KINDS = [
  "Claim_Form",
  "Police_Report",
  "Medical_Records",
  "Repair_Estimate",
  "Photos_Bundle",
  "Correspondence",
];

const LOREM =
  "The claimant submitted the attached documentation in support of the loss event. " +
  "Adjuster review notes and supporting evidence follow on subsequent pages. " +
  "All figures are denominated in USD unless otherwise stated. ";

/** Build the metadata list for a claim's documents (cheap, no page content). */
export function getClaimDocs(claim: Claim): DocMeta[] {
  const docs: DocMeta[] = [];
  // Distribute the claim's total payload across docCount documents.
  let remainingMB = claim.docSizeMB;
  for (let i = 0; i < claim.docCount; i++) {
    const isLast = i === claim.docCount - 1;
    const sizeMB = isLast
      ? Math.max(20, remainingMB)
      : Math.max(20, Math.round(remainingMB / (claim.docCount - i)));
    remainingMB -= sizeMB;
    const sizeBytes = sizeMB * 1024 * 1024;
    const pageCount = Math.max(8, Math.round(sizeBytes / BYTES_PER_PAGE));
    const kind = DOC_KINDS[(hash(claim.id) + i) % DOC_KINDS.length];
    docs.push({
      id: `${claim.id}-DOC-${i + 1}`,
      claimId: claim.id,
      name: `${kind}_${claim.id}.pdf`,
      sizeBytes,
      pageCount,
      mime: "application/pdf",
      uploadedAt: claim.submittedAt,
    });
  }
  return docs;
}

/**
 * Stream a window of page descriptors. Simulates a ranged fetch with latency.
 * Returns only the requested slice — the caller (virtualizer) requests the
 * narrow band of pages around the viewport.
 */
export async function fetchPages(
  doc: DocMeta,
  start: number,
  count: number,
): Promise<DocPage[]> {
  await new Promise((r) => setTimeout(r, 90 + Math.random() * 160));
  const end = Math.min(doc.pageCount, start + count);
  const pages: DocPage[] = [];
  const base = hash(doc.id);
  for (let i = start; i < end; i++) {
    const seed = (base + i * 2654435761) >>> 0;
    pages.push({
      index: i,
      width: 850,
      height: 1100,
      seed,
      textPreview:
        `Page ${i + 1} — ${doc.name}\n\n` +
        LOREM.repeat(2 + (seed % 3)),
    });
  }
  return pages;
}
