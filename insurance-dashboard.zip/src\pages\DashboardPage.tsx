import { useAuth } from "../auth/AuthContext";
import { ClaimsGrid } from "../components/grid/ClaimsGrid";
import { RoleSwitcher } from "../components/layout/RoleSwitcher";
import { StatStrip } from "../components/layout/StatStrip";
import { IconSearch } from "../components/ui/icons";

export function DashboardPage() {
  const { user } = useAuth();
  return (
    <div className="main">
      <header className="topbar">
        <h1>
          Hello {user.name} <span style={{ fontSize: 22 }}>👋</span>
        </h1>
        <div className="right">
          <div className="searchbox">
            <IconSearch size={18} />
            <input placeholder="Search" />
          </div>
          <RoleSwitcher />
        </div>
      </header>

      <StatStrip />
      <ClaimsGrid />
    </div>
  );
}
