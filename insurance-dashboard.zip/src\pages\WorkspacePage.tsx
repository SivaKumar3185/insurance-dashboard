import { useEffect, useMemo, useState } from "react";
import { useStore } from "../store/useStore";
import { getClaimDocs } from "../mocks/mockDocuments";
import { formatBytes, ProgressBar, Spinner } from "../components/ui/primitives";
import { toast } from "../components/ui/toast";
import {
  IconBack,
  IconFile,
  IconHighlight,
  IconNote,
  IconRedact,
  IconWand,
} from "../components/ui/icons";
import { DocumentViewer } from "../components/document/DocumentViewer";
import { SidePanel } from "../components/document/SidePanel";
import { OperationsBar } from "../components/document/OperationsBar";
import { useDocWorker } from "../components/document/useDocWorker";
import type { Tool } from "../components/document/DocPageView";
import type { DocOpKind } from "../types";
import { useAuth } from "../auth/AuthContext";

const OP_LABEL: Record<DocOpKind, string> = {
  split: "Splitting document",
  merge: "Merging documents",
  "delete-pages": "Deleting pages",
  export: "Exporting document",
};

export function WorkspacePage() {
  const { can } = useAuth();
  const claim = useStore((s) => s.activeClaim);
  const back = useStore((s) => s.backToDashboard);

  const docs = useMemo(() => (claim ? getClaimDocs(claim) : []), [claim]);
  const [activeDocId, setActiveDocId] = useState(docs[0]?.id ?? "");
  const activeDoc = docs.find((d) => d.id === activeDocId) ?? docs[0];

  const [tool, setTool] = useState<Tool>("select");
  const [scale, setScale] = useState(1);
  const [currentPage, setCurrentPage] = useState(0);

  const { progress, start, cancel, clear } = useDocWorker();
  const busy = !!progress && !progress.done;
  const canAnnotate = can("doc:annotate");

  // when the active document changes, reset transient view state
  useEffect(() => {
    setTool("select");
    setCurrentPage(0);
  }, [activeDocId]);

  if (!claim || !activeDoc) {
    return (
      <div className="ws" style={{ placeItems: "center", display: "grid" }}>
        <button className="ws-back" onClick={back}>
          <IconBack size={16} /> Back to claims
        </button>
      </div>
    );
  }

  const runOp = (kind: DocOpKind) => {
    start(kind, activeDoc.pageCount);
  };

  // surface completion / cancellation as a toast, then clear the overlay
  const onOpDone = () => {
    if (!progress) return;
    if (progress.error === "cancelled") {
      toast("info", `${OP_LABEL[progress.kind]} cancelled — document unchanged`);
    } else {
      toast("success", `${OP_LABEL[progress.kind]} complete · ${progress.phase}`);
    }
    clear();
  };

  const TOOLS: { id: Tool; label: string; icon: React.ReactNode }[] = [
    { id: "select", label: "Select / pan", icon: <IconWand size={18} /> },
    { id: "highlight", label: "Highlight", icon: <IconHighlight size={18} /> },
    { id: "note", label: "Note", icon: <IconNote size={18} /> },
    { id: "redaction", label: "Redact", icon: <IconRedact size={18} /> },
  ];

  return (
    <div className="ws">
      <div className="ws-top">
        <button className="ws-back" onClick={back}>
          <IconBack size={16} /> Back
        </button>
        <div className="ws-title">
          <b>{claim.claimant}</b> · {claim.id}
          <br />
          <span>
            {claim.policyType} claim · {claim.docCount} documents ·{" "}
            {formatBytes(claim.docSizeMB * 1024 * 1024)} total
          </span>
        </div>
        <OperationsBar busy={busy} onOp={runOp} />
      </div>

      <div className="ws-body">
        {/* document list */}
        <div className="ws-docs">
          <h4>Documents</h4>
          {docs.map((d) => (
            <button
              key={d.id}
              className={`doc-item ${d.id === activeDocId ? "active" : ""}`}
              onClick={() => setActiveDocId(d.id)}
            >
              <IconFile size={20} />
              <div className="dmeta">
                <div className="dname">{d.name}</div>
                <div className="dsub">
                  {formatBytes(d.sizeBytes)} · {d.pageCount.toLocaleString()} pages
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* viewer */}
        <div className="ws-viewer">
          <div className="viewer-bar">
            <div className="tools">
              {TOOLS.map((t) => (
                <button
                  key={t.id}
                  className={`tool-btn ${tool === t.id ? "active" : ""}`}
                  title={
                    t.id === "select" || canAnnotate
                      ? t.label
                      : `${t.label} — no permission for this role`
                  }
                  disabled={t.id !== "select" && !canAnnotate}
                  onClick={() => setTool(t.id)}
                >
                  {t.icon}
                </button>
              ))}
            </div>
            <span style={{ color: "var(--c-text-muted)" }}>
              {activeDoc.name} · streaming pages on demand
            </span>
            <div className="zoom">
              <button onClick={() => setScale((s) => Math.max(0.5, +(s - 0.1).toFixed(2)))}>
                −
              </button>
              <span style={{ minWidth: 44, textAlign: "center" }}>
                {Math.round(scale * 100)}%
              </span>
              <button onClick={() => setScale((s) => Math.min(2, +(s + 0.1).toFixed(2)))}>
                +
              </button>
            </div>
          </div>

          <DocumentViewer
            doc={activeDoc}
            tool={tool}
            scale={scale}
            onCurrentPage={setCurrentPage}
          />
        </div>

        {/* annotations + comments */}
        <SidePanel doc={activeDoc} currentPage={currentPage} />
      </div>

      {/* long-running op progress + cancel/retry */}
      {progress && (
        <div className="op-toast">
          <div className="ot-head">
            <b>{OP_LABEL[progress.kind]}</b>
            {!progress.done && <Spinner size={16} />}
          </div>
          <ProgressBar value={(progress.processed / progress.total) * 100} />
          <div className="ot-phase">
            <span>{progress.phase}</span>
            <span>
              {progress.processed.toLocaleString()} / {progress.total.toLocaleString()} pages
            </span>
          </div>
          <div className="ot-actions">
            {progress.done ? (
              <button className="btn btn-primary" onClick={onOpDone}>
                Done
              </button>
            ) : (
              <button className="btn btn-ghost" onClick={cancel}>
                Cancel
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
