import { create } from "zustand";
import type { Annotation, Claim, PageComment } from "../types";

type View = "dashboard" | "workspace";

interface AppState {
  view: View;
  activeClaim: Claim | null;
  sidebarCollapsed: boolean;

  // session-scoped document collaboration state, keyed by docId
  annotations: Record<string, Annotation[]>;
  comments: Record<string, PageComment[]>;

  toggleSidebar: () => void;
  openWorkspace: (claim: Claim) => void;
  backToDashboard: () => void;

  addAnnotation: (a: Annotation) => void;
  removeAnnotation: (docId: string, id: string) => void;

  addComment: (c: PageComment) => void;
  toggleCommentResolved: (docId: string, id: string) => void;
}

export const useStore = create<AppState>((set) => ({
  view: "dashboard",
  activeClaim: null,
  sidebarCollapsed: true,
  annotations: {},
  comments: {},

  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  openWorkspace: (claim) => set({ view: "workspace", activeClaim: claim }),
  backToDashboard: () => set({ view: "dashboard" }),

  addAnnotation: (a) =>
    set((s) => ({
      annotations: {
        ...s.annotations,
        [a.docId]: [...(s.annotations[a.docId] ?? []), a],
      },
    })),
  removeAnnotation: (docId, id) =>
    set((s) => ({
      annotations: {
        ...s.annotations,
        [docId]: (s.annotations[docId] ?? []).filter((a) => a.id !== id),
      },
    })),

  addComment: (c) =>
    set((s) => ({
      comments: {
        ...s.comments,
        [c.docId]: [...(s.comments[c.docId] ?? []), c],
      },
    })),
  toggleCommentResolved: (docId, id) =>
    set((s) => ({
      comments: {
        ...s.comments,
        [docId]: (s.comments[docId] ?? []).map((c) =>
          c.id === id ? { ...c, resolved: !c.resolved } : c,
        ),
      },
    })),
}));
