// ---------------------------------------------------------------------------
// Domain types — ABC Insurance Claims Adjudication Workbench
// ---------------------------------------------------------------------------

export type ClaimStatus =
  | "New"
  | "In Review"
  | "Approved"
  | "Rejected"
  | "Pending Docs";

export type Channel = "Email" | "SFTP" | "Web Portal" | "Mobile App" | "Fax";

export type PolicyType = "Auto" | "Home" | "Health" | "Life" | "Travel" | "Commercial";

export interface Claim {
  id: string; // CLM-XXXXXX
  claimant: string;
  company: string;
  policyType: PolicyType;
  channel: Channel;
  phone: string;
  email: string;
  country: string;
  amount: number; // claim amount in USD
  status: ClaimStatus;
  assignedTo: string | null; // adjuster name
  region: string;
  submittedAt: string; // ISO date
  docCount: number;
  docSizeMB: number; // total associated document payload
  priority: "Low" | "Medium" | "High";
}

// ---------------------------------------------------------------------------
// Server query contract (what the grid sends to the "backend")
// ---------------------------------------------------------------------------

export type SortDir = "asc" | "desc";

export interface SortSpec {
  field: keyof Claim;
  dir: SortDir;
}

export interface ClaimFilters {
  search?: string;
  status?: ClaimStatus[];
  channel?: Channel[];
  policyType?: PolicyType[];
  assignedToMe?: boolean;
}

export interface ClaimQuery {
  page: number; // 0-based
  pageSize: number;
  sort?: SortSpec;
  filters?: ClaimFilters;
}

export interface Page<T> {
  rows: T[];
  total: number; // total matching the filter (authorization-scoped)
  page: number;
  pageSize: number;
  tookMs: number; // server-reported timing (for the UX latency readout)
}

// ---------------------------------------------------------------------------
// Large-document model
// ---------------------------------------------------------------------------

export interface DocMeta {
  id: string;
  claimId: string;
  name: string;
  sizeBytes: number;
  pageCount: number;
  mime: string;
  uploadedAt: string;
}

export interface DocPage {
  index: number; // 0-based
  width: number;
  height: number;
  // In a real system this would be a tile/stream URL. Mocked here as a seed
  // the worker turns into deterministic rendered content.
  seed: number;
  textPreview: string;
}

export interface Annotation {
  id: string;
  docId: string;
  pageIndex: number;
  // normalized rect (0..1) so it scales with zoom
  x: number;
  y: number;
  w: number;
  h: number;
  type: "highlight" | "note" | "redaction";
  color: string;
  author: string;
  text?: string;
  createdAt: string;
}

export interface PageComment {
  id: string;
  docId: string;
  pageIndex: number;
  author: string;
  body: string;
  createdAt: string;
  resolved: boolean;
}

// Long-running, cancellable document operation (split / merge / delete pages)
export type DocOpKind = "split" | "merge" | "delete-pages" | "export";

export interface DocOpProgress {
  jobId: string;
  kind: DocOpKind;
  processed: number;
  total: number;
  phase: string;
  done: boolean;
  error?: string;
}
