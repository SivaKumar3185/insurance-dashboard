/// <reference lib="webworker" />
import type { DocOpKind, DocOpProgress } from "../types";

// ---------------------------------------------------------------------------
// Document operations worker.
//
// Split / merge / delete-pages / export on a 1GB document are CPU + IO heavy.
// Running them on the main thread would jank the UI. So they run HERE, off the
// main thread, in CHUNKS, reporting incremental progress and honouring cancel.
//
// In production each "chunk" would be a ranged read + transform + write of a
// page batch (e.g. via pdf-lib / a server stream). Here we simulate the work
// with a deterministic busy-wait per chunk so progress + cancel are real.
// ---------------------------------------------------------------------------

type StartMsg = {
  type: "start";
  jobId: string;
  kind: DocOpKind;
  totalPages: number;
};
type CancelMsg = { type: "cancel"; jobId: string };
type InMsg = StartMsg | CancelMsg;

const cancelled = new Set<string>();

self.onmessage = (e: MessageEvent<InMsg>) => {
  const msg = e.data;
  if (msg.type === "cancel") {
    cancelled.add(msg.jobId);
    return;
  }
  if (msg.type === "start") {
    void run(msg);
  }
};

const PHASES: Record<DocOpKind, string[]> = {
  split: ["Indexing pages", "Writing segment A", "Writing segment B", "Finalizing"],
  merge: ["Reading source A", "Reading source B", "Stitching pages", "Finalizing"],
  "delete-pages": ["Rebuilding page tree", "Compacting", "Finalizing"],
  export: ["Rasterizing", "Compressing", "Packaging", "Finalizing"],
};

function post(p: DocOpProgress) {
  (self as DedicatedWorkerGlobalScope).postMessage(p);
}

async function run(msg: StartMsg) {
  const { jobId, kind, totalPages } = msg;
  const phases = PHASES[kind];
  const CHUNK = Math.max(1, Math.round(totalPages / 60)); // ~60 progress ticks
  let processed = 0;
  const t0 = performance.now();

  while (processed < totalPages) {
    if (cancelled.has(jobId)) {
      cancelled.delete(jobId);
      post({
        jobId,
        kind,
        processed,
        total: totalPages,
        phase: "Cancelled",
        done: true,
        error: "cancelled",
      });
      return;
    }

    // simulate per-chunk CPU work (kept small so cancel stays responsive)
    busy(6);
    processed = Math.min(totalPages, processed + CHUNK);

    const frac = processed / totalPages;
    const phase = phases[Math.min(phases.length - 1, Math.floor(frac * phases.length))];
    post({ jobId, kind, processed, total: totalPages, phase, done: false });

    // yield to the event loop so cancel messages are received
    await new Promise((r) => setTimeout(r, 16));
  }

  post({
    jobId,
    kind,
    processed: totalPages,
    total: totalPages,
    phase: `Done in ${Math.round(performance.now() - t0)}ms`,
    done: true,
  });
}

function busy(ms: number) {
  const end = performance.now() + ms;
  while (performance.now() < end) {
    /* simulate synchronous chunk work */
  }
}
